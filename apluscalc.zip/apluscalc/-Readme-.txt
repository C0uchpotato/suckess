The Ultimate Calculus Collection!!
By: Chip Hurst

Welcome and thanks for downloading my program.  This is one of the best
calculus programs out there.  I am sure you will be happy with the
download, but if you are not, or if you find a bug, e-mail me
at chipcalc@gmail.com

---Note---

1.  Eventhough this is an application, you still need to have free RAM
    (sorry).  I recommend you have all RAM free, but you can get by
    with at least 13000 free.

2.  This program requires that you send the PrettyPt and Symbolic Apps
    to your calculator.  You must also install Symbolic (by that I mean
    open the application and select install).  I also
    recommend you install Omnicalc, because it makes Symbolic run
    faster and cause it is just an all around great App.

MOST COMMON QUESTIONS:

Q: I get an ERR: Argument, what am I doing wrong?
A: Read step 2 again, you must open Symbolic and select install
   (I highly recommend you do the same with Omnicalc too.)

Q: In implicit differentiation, what do you mean by equality?
A: Enter the equation as is, e.g. x^2+2=y^2+y.
   To get the '=' symbol, press 2nd MATH.

Q: I get an ERR: Undefined when I try a Taylor series, why?
A: This is an error in Martin Warmer's BasicBuilder program, but if
   you send _theta_W_theta_5.8xp to your calculator, this should fix it.

Q: What does Pn(x), n=? mean in the Taylor series section?
A: n is the degree of the polynomial to be generated
   EX: f(x)=e^x, x=0, n=2 --> Pn(x) = 1+x+x^2/2

CHECK BACK IN A COUPLE MONTHS FOR A MUCH MORE EXTENSIVE README!